Inputs are given in 298K folder to run a simulations

openmpi/3.0.0-intel

make clean

make 