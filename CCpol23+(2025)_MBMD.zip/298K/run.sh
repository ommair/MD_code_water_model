#!/bin/bash
#
#SBATCH --job-name=MY_MD_mpi
#SBATCH --output=myjob-%A_%a.out
#SBATCH --error=myjob-%A_%a.err
#SBATCH --partition=kolos2
#
###SBATCH --constraint="infiniband"
#SBATCH --nodes=1
#SBATCH --tasks-per-node=32
##SBATCH --ntasks=128
#SBATCH --cpus-per-task=1
#SBATCH --time=7-00:00:0
#SBATCH --mem-per-cpu=1024MB
#SBATCH --exclude=kolos2-node06,kolos2-node08,kolos2-node12,kolos2-node14


echo "***********************************************"
hostname
ulimit -a

##SBATCH --ntasks-per-core=1
##SBATCH --exclusive


# this job requests 32 cores. Cores can be selected from various nodes.

df -h 
ls 
echo $JOBDIR
 
module load openmpi/3.0.0-intel

EXE=/data/ommair/My_MD_MC_Codes/MD_FCC_VV_NBind_ES_3B_MPI_NVE_NVT_NPT/md_runs/NVE_NVT_NPT_runs_ccpol23plus/data_80181_nolrd_out010_orig_nofs2/NPT_w_rf_SLR/ravg3b_runs/ccpol8s/source_W_rf_check_SLR_ravg_rf_restart_codex_correction/execute

mpirun $EXE
